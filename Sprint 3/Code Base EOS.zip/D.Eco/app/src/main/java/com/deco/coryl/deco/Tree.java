package com.deco.coryl.deco;

import android.os.AsyncTask;

import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.LatLng;
import com.google.maps.android.clustering.ClusterItem;

/**
 * Created by coryl on 9/22/2017.
 */

public class Tree implements ClusterItem{

    /*private String common_name = "";
    private String scientific_name = "";
    private double latitude = 0.0;
    private double longitude = 0.0;
    private int id = 0;*/

    private final LatLng position;
    private String mTitle ="";
    private String mSnippet="";


    public Tree(double lat, double lng) {
        position = new LatLng(lat, lng);
    }

    public Tree(double lat, double lng, String title, String snippet) {
        position = new LatLng(lat, lng);
        mTitle = title;
        mSnippet = snippet;
    }

    @Override
    public LatLng getPosition() {
        return position;
    }

    @Override
    public String getTitle() {
        return mTitle;
    }

    @Override
    public String getSnippet() {
        return mSnippet;
    }
}
